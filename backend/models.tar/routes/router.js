const express = require("express");
const router = express.Router();
const User = require("../models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const axios = require("axios");

// ─── Config ───────────────────────────────────────────────────────────────────
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key-change-this";
const PAYMENT_GATEWAY = "https://dgpaymapi.dgpaym.com";
const PAYMENT_SECRET_KEY ="ECD81E933F8ABDAC1FB6A1622D2A437B";
const GATEWAY_BASE_URL="https://dgpaymapi.dgpaym.com";
// ─── Axios instance for payment gateway ──────────────────────────────────────
const gatewayAxios = axios.create({
  baseURL: PAYMENT_GATEWAY,
  timeout: 15000,
  headers: { "Content-Type": "application/json" },
  // Never throw on any HTTP status — we handle all responses ourselves
  validateStatus: () => true,
});

// ─── Safe gateway call — never throws, always returns a result object ─────────
async function safePost(url, body) {
  try {
    const res = await gatewayAxios.post(url, body);
    // axios already parsed JSON; if body was empty/non-JSON, res.data is "" or raw string
    return { ok: true, data: res.data ?? null, status: res.status };
  } catch (err) {
    // Only reaches here on network/timeout errors (not HTTP errors)
    return { ok: false, data: null, status: 0, error: err.message };
  }
}

// ─── Helper: Generate MD5 Signature ──────────────────────────────────────────
function generateSign(params, secretKey) {
  const sorted = Object.keys(params)
    .filter(
      (k) =>
        k !== "sign" &&
        params[k] !== "" &&
        params[k] !== undefined &&
        params[k] !== null
    )
    .sort()
    .map((k) => `${k}=${params[k]}`)
    .join("&");

  const strToSign = sorted + (secretKey ? `&key=${secretKey}` : "");
  return crypto.createHash("md5").update(strToSign).digest("hex").toUpperCase();
}

// ─── Middleware: Verify JWT Token ─────────────────────────────────────────────
const verifyToken = (req, res, next) => {
  const token = req.headers["authorization"]?.split(" ")[1];

  if (!token) {
    return res.status(401).json({ success: false, message: "No token provided" });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.userId = decoded.userId;
    next();
  } catch (error) {
    return res.status(401).json({ success: false, message: "Invalid token" });
  }
};

// ════════════════════════════════════════════════════════════════════════════
//  USER ROUTES
// ════════════════════════════════════════════════════════════════════════════

// GET all users (protected)
router.get("/users", verifyToken, async (req, res) => {
  try {
    const users = await User.find().select("-password");
    res.status(200).json({ success: true, count: users.length, data: users });
  } catch (error) {
    res.status(500).json({ success: false, message: "Error fetching users", error: error.message });
  }
});

// GET single user by ID (protected)
router.get("/users/:id", verifyToken, async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select("-password");
    if (!user) return res.status(404).json({ success: false, message: "User not found" });
    res.status(200).json({ success: true, data: user });
  } catch (error) {
    res.status(500).json({ success: false, message: "Error fetching user", error: error.message });
  }
});

// POST - Register new user
router.post("/users/register", async (req, res) => {
  try {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
      return res.status(400).json({ success: false, message: "Please provide all required fields" });
    }

    const existingUser = await User.findOne({ $or: [{ email }, { username }] });
    if (existingUser) {
      return res.status(400).json({ success: false, message: "User with this email or username already exists" });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const user = await User.create({ username, email, password: hashedPassword });

    const token = jwt.sign(
      { userId: user._id, email: user.email },
      JWT_SECRET,
      { expiresIn: "7d" }
    );

    user.password = undefined;
    res.status(201).json({ success: true, message: "User created successfully", data: user, token });
  } catch (error) {
    res.status(400).json({ success: false, message: "Error creating user", error: error.message });
  }
});

// POST - Login user
router.post("/users/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, message: "Please provide email and password" });
    }

    const user = await User.findOne({ email });
    if (!user) return res.status(401).json({ success: false, message: "Invalid credentials" });

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) return res.status(401).json({ success: false, message: "Invalid credentials" });

    const token = jwt.sign(
      { userId: user._id, email: user.email },
      JWT_SECRET,
      { expiresIn: "7d" }
    );

    user.password = undefined;
    res.status(200).json({ success: true, message: "Login successful", data: user, token });
  } catch (error) {
    res.status(500).json({ success: false, message: "Error during login", error: error.message });
  }
});

// PUT - Update user (protected)
router.put("/users/:id", verifyToken, async (req, res) => {
  try {
    const { username, email, password } = req.body;
    const updateData = {};

    if (username) updateData.username = username;
    if (email) updateData.email = email;
    if (password) {
      const salt = await bcrypt.genSalt(10);
      updateData.password = await bcrypt.hash(password, salt);
    }

    const user = await User.findByIdAndUpdate(req.params.id, updateData, {
      new: true,
      runValidators: true,
    }).select("-password");

    if (!user) return res.status(404).json({ success: false, message: "User not found" });
    res.status(200).json({ success: true, message: "User updated successfully", data: user });
  } catch (error) {
    res.status(400).json({ success: false, message: "Error updating user", error: error.message });
  }
});

// DELETE - Delete user (protected)
router.delete("/users/:id", verifyToken, async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) return res.status(404).json({ success: false, message: "User not found" });
    res.status(200).json({ success: true, message: "User deleted successfully" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Error deleting user", error: error.message });
  }
});

// GET - Current user profile (protected)
router.get("/me", verifyToken, async (req, res) => {
  try {
    const user = await User.findById(req.userId).select("-password");
    if (!user) return res.status(404).json({ success: false, message: "User not found" });
    res.status(200).json({ success: true, data: user });
  } catch (error) {
    res.status(500).json({ success: false, message: "Error fetching user", error: error.message });
  }
});

// ════════════════════════════════════════════════════════════════════════════
//  PAYMENT ROUTES
// ════════════════════════════════════════════════════════════════════════════
const crypto = require('crypto');

function generateSign(payload, secretKey) {
  // Create a copy without the sign field
  const signData = { ...payload };
  delete signData.sign;
  
  // Sort keys alphabetically
  const sortedKeys = Object.keys(signData).sort();
  
  // Build query string
  const signString = sortedKeys
    .map(key => {
      let value = signData[key];
      
      // Handle different types
      if (typeof value === 'boolean') {
        value = value.toString(); // 'true' or 'false'
      } else if (typeof value === 'number') {
        value = value.toString();
      } else {
        value = String(value).trim();
      }
      
      return `${key}=${value}`;
    })
    .join('&');
  
  // CRITICAL: Use 'secretKey' parameter name
  const stringToSign = `${signString}&secretKey=${secretKey}`;
  
  console.log("🔐 String to sign:", stringToSign);
  
  // Generate MD5 hash
  const signature = crypto
    .createHash('md5')
    .update(stringToSign)
    .digest('hex')
    .toUpperCase();
  
  return signature;
}

router.post("/payment/order/create", async (req, res) => {
  try {
    const {
      mchId,
      productId,
      mchOrderNo,
      amount,
      clientIp,
      notifyUrl,
      returnUrl,
      subject,
      body,
      param1,
      param2,
      validateUserName,
      requestCardInfo,
    } = req.body;

    // Validate required fields
    if (!mchId || !productId || !mchOrderNo || !amount || !clientIp || !notifyUrl) {
      return res.status(400).json({
        success: false,
        message: "Missing required fields: mchId, productId, mchOrderNo, amount, clientIp, notifyUrl",
      });
    }

    // Create payload - use strings consistently
    const payload = {
      mchId: String(mchId).trim(),
      productId: String(productId).trim(),
      mchOrderNo: String(mchOrderNo).trim(),
      amount: String(amount).trim(),  // Use string, not number
      clientIp: String(clientIp).trim(),
      notifyUrl: String(notifyUrl).trim(),
    };

    // Add optional fields
    if (returnUrl && returnUrl.trim()) payload.returnUrl = String(returnUrl).trim();
    if (subject && subject.trim()) payload.subject = String(subject).trim();
    if (body && body.trim()) payload.body = String(body).trim();
    if (param1 && param1.trim()) payload.param1 = String(param1).trim();
    if (param2 && param2.trim()) payload.param2 = String(param2).trim();
    if (validateUserName && validateUserName.trim()) payload.validateUserName = String(validateUserName).trim();
    if (requestCardInfo !== undefined) payload.requestCardInfo = requestCardInfo;

    // Generate signature
    const sign = generateSign(payload, PAYMENT_SECRET_KEY);
    payload.sign = sign;

    console.log("📤 Final payload:", JSON.stringify(payload, null, 2));

    // Call gateway
    const response = await axios.post(
      `${GATEWAY_BASE_URL}/v1.0/api/order/create`,
      payload,
      {
        headers: {
          'Content-Type': 'application/json',
        },
        timeout: 30000
      }
    );
   console.log("response",response.data)
    return res.status(200).json({
      success: true,
      message: "Order created successfully",
      data: response.data,
    });

  } catch (error) {
    console.error("❌ Error:", error.response?.data || error.message);
    res.status(500).json({ 
      success: false, 
      message: "Error creating payment order", 
      error: error.response?.data || error.message
    });
  }
});
// ─── 2. Query Collection Order ────────────────────────────────────────────────
// POST /payment/order/query
//
// Required body: mchId, mchOrderNo
router.post("/payment/order/query", async (req, res) => {
  try {
    const { mchId, mchOrderNo } = req.body;

    if (!mchId || !mchOrderNo) {
      return res.status(400).json({
        success: false,
        message: "Missing required fields: mchId, mchOrderNo",
      });
    }

    const payload = { mchId, mchOrderNo };
    payload.sign = generateSign(payload, PAYMENT_SECRET_KEY);

    console.log("📤 [order/query] payload →", JSON.stringify(payload, null, 2));

    const { ok, data, status, error: netErr } = await safePost("/v1.0/api/order/query", payload);

    if (!ok) {
      console.error("❌ [order/query] network error:", netErr);
      return res.status(502).json({
        success: false,
        message: "Could not reach payment gateway",
        error: netErr,
      });
    }

    console.log(`📥 [order/query] gateway HTTP ${status} →`, data);

    res.status(200).json({ success: true, message: "Order query successful", data });
  } catch (error) {
    console.error("❌ [order/query] exception:", error);
    res.status(500).json({ success: false, message: "Error querying payment order", error: error.message });
  }
});

// ─── 3. Collection Result Notification / Callback ────────────────────────────
// GET /payment/callback
//
// Gateway calls this URL when payment status changes.
// MUST return plain text "success" to stop gateway retries.
//
// Status codes:
//   0  = In progress
//   1  = Completed ✅
//   3  = Timeout   (may still complete — do NOT mark as failed)
//   10 = Created
//   11 = Failed ❌
router.get("/payment/callback", async (req, res) => {
  try {
    const {
      payOrderId,
      mchId,
      productId,
      mchOrderNo,
      amount,
      realAmount,
      income,
      status,
      paySuccessTime,
      sign,
      param1,
      param2,
      utr,
    } = req.query;

    console.log("📩 [callback] received →", req.query);

    // Validate all required params
    const required = {
      payOrderId, mchId, productId, mchOrderNo,
      amount, realAmount, income, status,
      paySuccessTime, sign, param1, param2,
    };
    const missing = Object.keys(required).filter(
      (k) => required[k] === undefined || required[k] === null || required[k] === ""
    );

    if (missing.length > 0) {
      console.error("⚠️  [callback] missing params:", missing);
      return res.status(400).send("MISSING_PARAMS");
    }

    // Verify signature
    const signPayload = {
      payOrderId, mchId, productId, mchOrderNo,
      amount, realAmount, income, status,
      paySuccessTime, param1, param2,
      ...(utr ? { utr } : {}),
    };
    const expectedSign = generateSign(signPayload, PAYMENT_SECRET_KEY);

    if (sign !== expectedSign) {
      console.error("🚫 [callback] signature mismatch", { received: sign, expected: expectedSign });
      return res.status(400).send("INVALID_SIGN");
    }

    // Handle payment status
    const paymentStatus = parseInt(status, 10);

    switch (paymentStatus) {
      case 1: {
        console.log(`✅ Payment SUCCESS — Order: ${mchOrderNo} | Amount: ${amount} | Real: ${realAmount} | UTR: ${utr || "N/A"}`);
        // TODO: Update your Order document in MongoDB
        // const Order = require("../models/Order");
        // await Order.findOneAndUpdate(
        //   { mchOrderNo },
        //   { status: "completed", utr, paidAt: new Date(Number(paySuccessTime)), realAmount, income }
        // );
        // TODO: Credit user balance (param1 = userId set when creating order)
        // await User.findByIdAndUpdate(param1, { $inc: { balance: Number(realAmount) } });
        break;
      }
      case 3: {
        console.warn(`⏳ Payment TIMEOUT — Order: ${mchOrderNo} (may still complete later)`);
        // TODO: await Order.findOneAndUpdate({ mchOrderNo }, { status: "timeout" });
        break;
      }
      case 11: {
        console.error(`❌ Payment FAILED — Order: ${mchOrderNo}`);
        // TODO: await Order.findOneAndUpdate({ mchOrderNo }, { status: "failed" });
        break;
      }
      case 0:
      case 10:
      default: {
        console.log(`ℹ️  Payment status ${paymentStatus} — Order: ${mchOrderNo}`);
        break;
      }
    }

    // Always return plain "success" — stops gateway retry loop
    return res.status(200).send("success");

  } catch (error) {
    console.error("❌ [callback] exception:", error.message);
    // Return "success" even on error to prevent infinite retries
    return res.status(200).send("success");
  }
});

// ─── 4. Transaction History ───────────────────────────────────────────────────
// GET /payment/history?mchId=xxx  (protected)
//
// Returns the user's saved orders from your own DB.
// Uncomment the Order model lines once you create models/Order.js
router.get("/payment/history", verifyToken, async (req, res) => {
  try {
    const { mchId } = req.query;

    if (!mchId) {
      return res.status(400).json({ success: false, message: "mchId is required" });
    }

    // TODO: Uncomment once you have an Order model
    // const Order = require("../models/Order");
    // const orders = await Order.find({ mchId }).sort({ createdAt: -1 }).limit(50);
    // return res.status(200).json({ success: true, data: orders });

    // Placeholder response until Order model is ready
    res.status(200).json({ success: true, data: [] });
  } catch (error) {
    res.status(500).json({ success: false, message: "Error fetching history", error: error.message });
  }
});

module.exports = router;